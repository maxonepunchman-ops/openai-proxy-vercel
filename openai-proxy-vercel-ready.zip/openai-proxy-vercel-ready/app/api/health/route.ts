export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

function getTokenFromRequest(request: Request) {
  const url = new URL(request.url)
  const queryToken = url.searchParams.get('token')?.trim() || ''
  const headerToken = request.headers.get('x-proxy-secret')?.trim() || ''
  const authorization = request.headers.get('authorization') || ''
  const bearerToken = authorization.match(/^Bearer\s+(.+)$/i)?.[1]?.trim() || ''

  return queryToken || headerToken || bearerToken
}

function mask(value: string | undefined) {
  if (!value) return null
  if (value.length <= 10) return '***'
  return `${value.slice(0, 4)}...${value.slice(-4)}`
}

export async function GET(request: Request) {
  const proxySecret = process.env.PROXY_SECRET?.trim()
  const requestToken = getTokenFromRequest(request)

  if (!proxySecret) {
    return Response.json(
      {
        ok: false,
        error: 'На Vercel-прокси не задана переменная PROXY_SECRET',
      },
      { status: 500 },
    )
  }

  if (requestToken !== proxySecret) {
    return Response.json(
      {
        ok: false,
        error: 'Неверный token. Используйте /api/health?token=ВАШ_PROXY_SECRET',
      },
      { status: 401 },
    )
  }

  return Response.json({
    ok: true,
    proxy: 'running',
    openAiKeyConfigured: Boolean(process.env.OPENAI_API_KEY?.trim()),
    proxySecretConfigured: Boolean(proxySecret),
    upstream: process.env.OPENAI_UPSTREAM_CHAT_COMPLETIONS_URL || 'https://api.openai.com/v1/chat/completions',
    openAiKeyMask: mask(process.env.OPENAI_API_KEY),
  })
}
