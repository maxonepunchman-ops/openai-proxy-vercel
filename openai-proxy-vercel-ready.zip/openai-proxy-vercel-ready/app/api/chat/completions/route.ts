export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

export { OPTIONS, POST } from '../../../v1/chat/completions/route'
