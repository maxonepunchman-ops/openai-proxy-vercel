export default function Page() {
  return (
    <main>
      <section className="card">
        <span className="badge">● Прокси запущен</span>
        <h1>OpenAI proxy для Timeweb</h1>
        <p>
          Этот проект не показывает ключ OpenAI наружу. Основной сайт на Timeweb обращается сюда как к OpenAI-compatible endpoint.
        </p>

        <div className="grid">
          <div>
            <p><strong>Адрес для Timeweb:</strong></p>
            <pre><code>OPENAI_PROXY_URL=https://ВАШ-ДОМЕН.vercel.app/v1</code></pre>
          </div>
          <div>
            <p><strong>Проверка:</strong></p>
            <pre><code>/api/health?token=ВАШ_PROXY_SECRET</code></pre>
          </div>
        </div>

        <p>
          Настоящий <code>OPENAI_API_KEY</code> должен лежать только в настройках этого проекта на Vercel.
        </p>
      </section>
    </main>
  )
}
