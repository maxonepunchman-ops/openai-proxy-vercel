import type { Metadata } from 'next'
import './styles.css'

export const metadata: Metadata = {
  title: 'OpenAI Proxy for Timeweb',
  description: 'Secure OpenAI-compatible proxy for projects hosted on Timeweb',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  )
}
